#define BLYNK_TEMPLATE_ID "TMPL323R__8X4"
#define BLYNK_TEMPLATE_NAME "Smart Light Classifier"
#define BLYNK_AUTH_TOKEN "X_V0787pkLz8N3OqHydrEVc9iaS9udb9"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ArduTFLite.h>
#include "model.h"

// ---------- WiFi ----------
char ssid[] = "Wokwi-GUEST";
char pass[] = "";

// ---------- Pins ----------
#define LDR_PIN 34
#define LED_PIN 2

#define SDA_PIN 21
#define SCL_PIN 22

// ---------- OLED ----------
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  -1
);

// ---------- TinyML ----------
constexpr int TENSOR_ARENA_SIZE = 64 * 1024;

alignas(16) uint8_t tensorArena[TENSOR_ARENA_SIZE];

BlynkTimer timer;

// =================================================
// SETUP
// =================================================

void setup()
{
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("================================");
  Serial.println(" SMART LIGHT CLASSIFIER");
  Serial.println("================================");

  pinMode(LDR_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);

  digitalWrite(LED_PIN, LOW);

  analogReadResolution(12);

  // ---------- OLED ----------
  Wire.begin(SDA_PIN, SCL_PIN);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C))
  {
    Serial.println("OLED ERROR");
    while (1);
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);

  display.println("SMART LIGHT");
  display.println("CLASSIFIER");
  display.println();
  display.println("Starting...");

  display.display();

  delay(1000);

  // ---------- TinyML ----------
  Serial.println("Initializing TinyML...");

  if (!modelInit(
        model,
        tensorArena,
        TENSOR_ARENA_SIZE))
  {
    Serial.println("TinyML initialization FAILED!");

    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("TINYML ERROR");
    display.println();
    display.println("MODEL FAILED");
    display.display();

    while (1);
  }

  Serial.println("TinyML Ready!");

  // ---------- WiFi ----------
  Serial.println("Connecting WiFi...");

  WiFi.begin(ssid, pass);

  while (WiFi.status() != WL_CONNECTED)
  {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected!");

  Serial.print("IP: ");
  Serial.println(WiFi.localIP());

  // ---------- Blynk ----------
  Blynk.begin(
    BLYNK_AUTH_TOKEN,
    ssid,
    pass
  );

  Serial.println("Blynk Connected!");

  display.clearDisplay();
  display.setCursor(0, 0);

  display.println("SMART LIGHT");
  display.println();
  display.println("WiFi: CONNECTED");
  display.println("Blynk: CONNECTED");
  display.println("TinyML: READY");

  display.display();

  delay(2000);

  // ---------- Timer ----------
  timer.setInterval(1000L, readSensor);
}

// =================================================
// SENSOR + TINYML
// =================================================

void readSensor()
{
  int ldrValue = analogRead(LDR_PIN);

  // Convert LDR value to model input
  float input = (float)ldrValue / 4095.0;

  // Send input to model
  if (!modelSetInput(input, 0))
  {
    Serial.println("Input Error!");
    return;
  }

  // Run TinyML
  if (!modelRunInference())
  {
    Serial.println("Inference Error!");
    return;
  }

  // Get model outputs
  float dark = modelGetOutput(0);
  float normal = modelGetOutput(1);
  float bright = modelGetOutput(2);

  // Find highest output
  int result;
  float confidence;

  if (dark >= normal && dark >= bright)
  {
    result = 0;
    confidence = dark;
  }
  else if (normal >= dark && normal >= bright)
  {
    result = 1;
    confidence = normal;
  }
  else
  {
    result = 2;
    confidence = bright;
  }

  // ---------- Classification ----------
  String lightClass;

  if (result == 0)
  {
    lightClass = "DARK";
  }
  else if (result == 1)
  {
    lightClass = "NORMAL";
  }
  else
  {
    lightClass = "BRIGHT";
  }

  // ---------- Automatic LED ----------
  if (result == 0)
  {
    digitalWrite(LED_PIN, HIGH);
  }
  else
  {
    digitalWrite(LED_PIN, LOW);
  }

  String ledStatus;

  if (digitalRead(LED_PIN))
  {
    ledStatus = "ON";
  }
  else
  {
    ledStatus = "OFF";
  }

  // ---------- Serial ----------
  Serial.println("-----------------------------");

  Serial.print("LDR       : ");
  Serial.println(ldrValue);

  Serial.print("DARK      : ");
  Serial.println(dark, 4);

  Serial.print("NORMAL    : ");
  Serial.println(normal, 4);

  Serial.print("BRIGHT    : ");
  Serial.println(bright, 4);

  Serial.print("CLASS     : ");
  Serial.println(lightClass);

  Serial.print("CONFIDENCE: ");
  Serial.println(confidence, 4);

  Serial.print("LED       : ");
  Serial.println(ledStatus);

  // ---------- Blynk ----------
  Blynk.virtualWrite(V0, ldrValue);
  Blynk.virtualWrite(V1, lightClass);
  Blynk.virtualWrite(V2, ledStatus);

  // ---------- OLED ----------
  display.clearDisplay();

  display.setTextSize(1);
  display.setCursor(0, 0);

  display.println("SMART LIGHT");

  display.setCursor(0, 15);
  display.print("LDR: ");
  display.println(ldrValue);

  display.setCursor(0, 30);
  display.print("CLASS: ");
  display.println(lightClass);

  display.setCursor(0, 45);
  display.print("LED: ");
  display.println(ledStatus);

  display.display();
}

// =================================================
// LOOP
// =================================================

void loop()
{
  Blynk.run();
  timer.run();
}